<?php
define('DB_HOST', 'sql102.infinityfree.com');
define('DB_NAME', 'if0_42401203_asgardstore');
define('DB_USER', 'if0_42401203');
define('DB_PASS', '70PU5Trtox6');
define('SITE_URL', 'https://Asgard-Store.gamer.free');
define('DEBUG_MODE', true);
